let link = window.location.href;
(function youtube() {
  if (link.includes("youtube")) {
    function l1() {
      if (pulsanteskip()) {
        aspettanuovovideo(document.querySelector("video"));
        pulsanteskip().click();
      } else if (adtext()) {
        aspettanuovovideo(document.querySelector("video"));
        document.querySelector("video").currentTime =
          document.querySelector("video").duration;
      } else {
        requestAnimationFrame(l1);
      }
    }
    l1();
    function aspettanuovovideo(v) {
      if (document.querySelector("video") == v)
        requestAnimationFrame(aspettanuovovideo);
      else {
        l1();
      }
    }
    function pulsanteskip() {
      return document.querySelector(".ytp-ad-skip-button-modern");
    }
    function adtext() {
      return document.querySelector(".ytp-ad-text");
    }
  }
})();